/*
Model Definition of business contact
File name: contact.js
Name: Sarabun Tohura
Student no: 300685525
Date: 2021-06-17
*/

let mongoose = require('mongoose');

// create a model class
let contactModel = mongoose.Schema({
    name: String,
    contactno: String,
    email: String
},
{
    collection: "contacts"
});

module.exports = mongoose.model('Contact', contactModel);