/*
File name: db.js
Name: Sarabun Tohura
Student no: 300685525
Date: 2021-06-17
*/
module.exports = 
{
    // Below URI is used for localhost connection
    //"URI": "mongodb://localhost/business_contact"

    // Below URI is used to connect with mongoDB Atlas database
    "URI": "mongodb+srv://shahin:QY6mxBfoQ6RLrEFv@mongodbserver.me3cw.mongodb.net/business_contact?retryWrites=true&w=majority"
}