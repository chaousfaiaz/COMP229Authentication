let express = require('express');
let router = express.Router();

/* Contact page. */
router.get('/contact', function(req, res, next) {
  res.render('users', { title: 'Contact Me'});
});

module.exports = router;
